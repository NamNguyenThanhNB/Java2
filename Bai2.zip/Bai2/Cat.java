/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.io.Serializable;

/**
 *
 * @author nguye
 */
public class Cat implements Serializable {

    private String hoten, color;
    private int tuoi;

    public Cat(String hoten, String color, int tuoi) {
        this.hoten = hoten;
        this.color = color;
        this.tuoi = tuoi;
    }

    public Cat() {
    }

    @Override
    public String toString() {
        return hoten + "\t" + color + "\t" + tuoi;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

}
