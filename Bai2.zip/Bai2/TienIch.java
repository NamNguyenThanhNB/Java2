/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bai2;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class TienIch {

    public static Object readObject(String path) {
        ObjectInputStream ois = null;
        try {
            //tao doi tuong ghi
            ois = new ObjectInputStream(new FileInputStream(path));
            //thuc hien doc
            Object object = ois.readObject();
            //dong luong
            ois.close();
            return object;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                ois.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    public static Boolean writeObject(String path, Object obj) {
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(path));

            oos.writeObject(obj);
            return true;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                oos.flush();
                oos.close();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

}
