/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trenlop.bai3;

import java.io.FileReader;
import java.io.FileWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author Admin
 */
public class TienIch {

    public static String readFile(String fileName) {
        try {
            //B1:tao doi tuong
            FileReader fr = new FileReader(fileName);

            //B2:thuc hien doc
            String data = "";
            int c;
            //ham read se doc tung chu roi chuyen thanh so nen moi lam nhu nay
            while ((c = fr.read()) != -1) {//neu viec doc chua ket thuc
                data += (char) c;//ghi du lieu vao data
            }

            //B3:dong luong
            fr.close();

            return data;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public static boolean writeFile(String data, String fileName) {

        FileWriter fw = null;
        try {
            //ghi nd tren taContent ra file
            //b1:tao doi tuong
            fw = new FileWriter(fileName);//d://

            //b2: thuc hien ghi
            fw.write(data);
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                //b3:dong luong
                fw.flush();//xa luong
                fw.close();//dong luong
                return true;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }
}
