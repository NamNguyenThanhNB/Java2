/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oki123;

import java.io.Serializable;

/**
 *
 * @author Admin
 */
public class Info_ofFlim implements Serializable {

    String fc, fn, fs, sm, rd;

    public Info_ofFlim() {
    }

    public Info_ofFlim(String fc, String fn, String fs, String sm, String rd) {
        this.fc = fc;
        this.fn = fn;
        this.fs = fs;
        this.sm = sm;
        this.rd = rd;
    }

    @Override
    public String toString() {
        return "Info_ofFlim{" + "fc=" + fc + ", fn=" + fn + ", fs=" + fs + ", sm=" + sm + ", rd=" + rd + '}';
    }

    public String getFc() {
        return fc;
    }

    public void setFc(String fc) {
        this.fc = fc;
    }

    public String getFn() {
        return fn;
    }

    public void setFn(String fn) {
        this.fn = fn;
    }

    public String getFs() {
        return fs;
    }

    public void setFs(String fs) {
        this.fs = fs;
    }

    public String getSm() {
        return sm;
    }

    public void setSm(String sm) {
        this.sm = sm;
    }

    public String getRd() {
        return rd;
    }

    public void setRd(String rd) {
        this.rd = rd;
    }

}
